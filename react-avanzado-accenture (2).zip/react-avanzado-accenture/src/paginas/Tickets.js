import React,{useEffect, useContext} from "react"
import contexto from "../contexto"

const Tickets = () => {
    
    let {tickets , pedirRecursos} = useContext(contexto)

    //Este Hook está simulando el componentDidMount
    useEffect(()=>{
        if(!tickets.length){
        pedirRecursos("tickets")
        }
    },[]/* Este array de dependencias sirve para decirle al hook que queremos que se vuelva a ejecutar si todo lo que ponemos acá cambia. Como lo dejamos vacio, se ejecuta una única vez y listo */)

    return (
        <>
        
        {tickets.map((ticket)=>
            <table>
                <thead>
                <tr>
                    <th>Ticket ID</th> 
                    <th>Ticket Subject</th>
                    <th>User ID</th>
                </tr>
                </thead>
                <tbody>
                    <tr key={ticket.id}>
                    <td>{ticket.id}</td>
                    <td>{ticket.asunto}</td>
                    <td>{ticket.id_usuario}</td>
                    </tr>
                </tbody>
            </table>
        )}
        
        </>
    )
}

export default Tickets