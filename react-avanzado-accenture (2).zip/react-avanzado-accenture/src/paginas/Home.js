import React from "react"

const Home = () => <div>Home</div>

export default Home