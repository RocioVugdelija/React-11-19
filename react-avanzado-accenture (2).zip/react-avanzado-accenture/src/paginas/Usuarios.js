import React,{useEffect, useContext} from "react"
import contexto from "../contexto"

const Usuarios = () => {
    
    let { eliminarUsuario, usuarios, pedirRecursos} = useContext(contexto)
    


    //Este Hook está simulando el componentDidMount
    useEffect(()=>{
        if(!usuarios.length){
        pedirRecursos("usuarios")
        }
    },[]/* Este array de dependencias sirve para decirle al hook que queremos que se vuelva a ejecutar si todo lo que ponemos acá cambia. Como lo dejamos vacio, se ejecuta una única vez y listo */)

    return <div>
        
        {usuarios.map((usuario,i)=>
            <p key={i}>{usuario.name} 
                <button className="material-icons" onClick={eliminarUsuario.bind(null,i)}>clear</button> 
                <button className="material-icons">create</button> 
            </p>
        )}
        
        </div>
}

export default Usuarios