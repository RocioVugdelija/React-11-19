import React, {useState} from 'react'
import Header from './componentes/Header'
import Main from './componentes/Main'
import Footer from './componentes/Footer'
import {Provider} from "./contexto"

const App =() => {

    
    const [usuarios,setUsuarios] = useState([])
    const [tickets,setTickets] = useState([])

    let pedirRecursos = (recursos) =>{
        fetch("http://localhost:3000/"+recursos)
        .then((respuesta)=>{return respuesta.json()})
        .then((respuesta)=>{
            if (recursos === "tickets"){
                setTickets(respuesta)}
            else setUsuarios(respuesta)
        })
    }
    let eliminarUsuario = (indice) => {
        fetch(`http://localhost:3000/usuarios/${usuarios[indice].id}`,{
            method : "DELETE"
        })
        .then((response)=>{
            if (response.status == 200) {

                setUsuarios(usuarios)([
                    ...usuarios.slice(0,indice),
                    ...usuarios.slice(indice+1)
                ])
            }
        })
    }
        return(
            <Provider value={{usuarios,tickets,setUsuarios,setTickets,pedirRecursos,eliminarUsuario}}>
                <Header/>
                <Main/>
                <Footer/>
            </Provider>
        )
    
    
}
export default App;

/*

export default class App extends React.Component {

    constructor(){
        super()
        this.state = {
            usuarios : [],
            eliminarUsuario : this.eliminarUsuario,
            tickets: [],
            pedirRecursos: this.pedirRecursos,
        }
    }



    pedirRecursos = (recursos) =>{
        fetch("http://localhost:3000/"+recursos)
        .then((respuesta)=>{return respuesta.json()})
        .then((respuesta)=>{
            if (recursos === "tickets"){
            this.setState({ tickets : respuesta })}
            else this.setState({ usuarios: respuesta})
        })
    }




    eliminarUsuario = (indice) => {
        fetch(`http://localhost:3000/usuarios/${this.state.usuarios[indice].id}`,{
            method : "DELETE"
        })
        .then((response)=>{
            if (response.status == 200) {
                this.setState({ usuarios : [
                    ...this.state.usuarios.slice(0,indice),
                    ...this.state.usuarios.slice(indice+1)
                ]})     
            }
        })
    }

    render(){
        return(
            <Provider value={this.state}>
                <Header/>
                <Main pedirUsuarios={this.pedirUsuarios} />
                <Footer/>
            </Provider>
        )
    }
}*/