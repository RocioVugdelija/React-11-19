import {createContext} from "react"

let contexto = createContext()
/* 
export let Provider = contexto.Provider
export let Consumer = contexto.Consumer

export let {Provider:Provider,Consumer:Consumer} = contexto
*/
export let {Provider,Consumer} = contexto

export default contexto
