import React from 'react'
import Usuarios from '../paginas/Usuarios'
import Home from '../paginas/Home'
import Tickets from '../paginas/Tickets'
import {Route,Switch} from "react-router-dom"

const Main = ({pedirUsuarios},{pedirTickets}) => {
    return (
        <main>
            <h2>Home</h2>
            <Switch>
                <Route path="/" exact   component={Home}/>   
                <Route path="/usuarios" component={Usuarios}/>
                <Route path="/tickets"  component={Tickets}/>
            </Switch>
        </main>
    )
}

export default Main
